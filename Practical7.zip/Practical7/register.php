<?php
session_start();
if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>StudentHub | Register</title>

    <link rel="stylesheet" href="css/style.css">
    <script src="script.js" defer></script>
</head>

<body>

<header>

    <nav>
        <a href="index.html">Home</a>
        <a href="about.html">About</a>
        <a href="register.php">Register</a>
        <a href="login.html">Login</a>
        <a href="dashboard.html">Dashboard</a>
        <a href="events.html">Events</a>
        <a href="profile.html">Profile</a>
        <a href="contact.html">Contact</a>
        <a href="admin.html">Admin</a>
        <a href="feedback.html">Feedback</a>
        <a href="timetable.html">Timetable</a>
        <a href="attendance.html">Attendance</a>
    </nav>

    <hr>

</header>


<main>

    <p>
        <a href="index.html">Home</a> &gt; Register
    </p>


    <section>

        <h2>Student Registration Form</h2>

        <p class="form-note">
            Fields marked with
            <span aria-hidden="true">*</span>
            are required.
        </p>


        <form id="registrationForm" action="process_registration.php" method="POST" novalidate>

            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">

            <div class="form-group">

                <label for="regName">
                    Full Name
                    <span aria-hidden="true">*</span>
                </label>

                <input
                    type="text"
                    id="regName"
                    name="name"
                    required
                    minlength="3"
                    maxlength="50"
                    autocomplete="name"
                    aria-describedby="nameError"
                    placeholder="Enter your full name"
                >

                <small
                    id="nameError"
                    class="error-message"
                    aria-live="polite">
                </small>

            </div>

            <div class="form-group">

                <label for="regEmail">
                    Email
                    <span aria-hidden="true">*</span>
                </label>

                <input
                    type="email"
                    id="regEmail"
                    name="email"
                    required
                    autocomplete="email"
                    aria-describedby="emailError"
                    placeholder="example@gmail.com"
                >

                <small
                    id="emailError"
                    class="error-message"
                    aria-live="polite">
                </small>

            </div>


            <div class="form-group">

                <label for="regMobile">
                    Mobile Number
                    <span aria-hidden="true">*</span>
                </label>

                <input
                    type="tel"
                    id="regMobile"
                    name="mobile"
                    required
                    maxlength="10"
                    inputmode="numeric"
                    autocomplete="tel"
                    aria-describedby="mobileError"
                    placeholder="10 digit mobile number"
                >

                <small
                    id="mobileError"
                    class="error-message"
                    aria-live="polite">
                </small>

            </div>

            <div class="form-group">

                <label for="regPassword">
                    Password
                    <span aria-hidden="true">*</span>
                </label>

                <input
                    type="password"
                    id="regPassword"
                    name="password"
                    required
                    minlength="8"
                    autocomplete="new-password"
                    aria-describedby="passwordHelp passwordError"
                    placeholder="Create a strong password"
                >

                <small
                    id="passwordHelp"
                    class="help-text">

                    Use 8+ characters with uppercase,
                    lowercase, number and special character.

                </small>

                <div
                    class="strength-meter"
                    aria-hidden="true">

                    <div
                        id="strengthBar"
                        class="strength-bar">
                    </div>

                </div>

                <span
                    id="strengthText"
                    class="strength-text"
                    aria-live="polite">
                </span>

                <small
                    id="passwordError"
                    class="error-message"
                    aria-live="polite">
                </small>

            </div>

            <div class="form-group">

                <label for="confirmPassword">
                    Confirm Password
                    <span aria-hidden="true">*</span>
                </label>

                <input
                    type="password"
                    id="confirmPassword"
                    name="confirmPassword"
                    required
                    autocomplete="new-password"
                    aria-describedby="confirmPasswordError"
                    placeholder="Re-enter your password"
                >

                <small
                    id="confirmPasswordError"
                    class="error-message"
                    aria-live="polite">
                </small>

            </div>

            <div class="form-group">

                <label for="regCourse">
                    Course
                    <span aria-hidden="true">*</span>
                </label>

                <select
                    id="regCourse"
                    name="course"
                    required
                    aria-describedby="courseError">

                    <option value="">
                        -- Select Course --
                    </option>

                    <option value="B.Tech">
                        B.Tech
                    </option>

                    <option value="M.Tech">
                        M.Tech
                    </option>

                    <option value="B.Com">
                        B.Com
                    </option>

                    <option value="B.Sc">
                        B.Sc
                    </option>

                </select>

                <small
                    id="courseError"
                    class="error-message"
                    aria-live="polite">
                </small>

            </div>

            <div class="form-group">

                <label for="regYear">
                    Year
                    <span aria-hidden="true">*</span>
                </label>

                <select
                    id="regYear"
                    name="year"
                    required
                    aria-describedby="yearError">

                    <option value="">
                        -- Select Year --
                    </option>

                    <option value="1">
                        1st Year
                    </option>

                    <option value="2">
                        2nd Year
                    </option>

                    <option value="3">
                        3rd Year
                    </option>

                    <option value="4">
                        4th Year
                    </option>

                </select>

                <small
                    id="yearError"
                    class="error-message"
                    aria-live="polite">
                </small>

            </div>

            <fieldset
                class="form-group"
                aria-describedby="genderError">

                <legend>
                    Gender
                    <span aria-hidden="true">*</span>
                </legend>

                <div class="choice-group">

                    <label>
                        <input
                            type="radio"
                            name="gender"
                            value="Male">
                        Male
                    </label>

                    <label>
                        <input
                            type="radio"
                            name="gender"
                            value="Female">
                        Female
                    </label>

                    <label>
                        <input
                            type="radio"
                            name="gender"
                            value="Other">
                        Other
                    </label>

                </div>

                <small
                    id="genderError"
                    class="error-message"
                    aria-live="polite">
                </small>

            </fieldset>

            <div class="form-group terms-group">

                <label
                    class="checkbox-label"
                    for="terms">

                    <input
                        type="checkbox"
                        id="terms"
                        name="terms"
                        required
                        aria-describedby="termsError">

                    I accept the Terms and Conditions

                    <span aria-hidden="true">*</span>

                </label>

                <small
                    id="termsError"
                    class="error-message"
                    aria-live="polite">
                </small>

            </div>

            <div class="form-actions">

                <input
                    type="submit"
                    value="Register">

                <input
                    type="reset"
                    value="Clear">

            </div>



            <!-- Success Message -->

            <p
                id="registrationSuccess"
                class="success-message"
                role="status"
                aria-live="polite">
            </p>


        </form>

    </section>

</main>


<footer>

    <hr>

    <p>© 2026 StudentHub Portal</p>

</footer>


</body>
</html>